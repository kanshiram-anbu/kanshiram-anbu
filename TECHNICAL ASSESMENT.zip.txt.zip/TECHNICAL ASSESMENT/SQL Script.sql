
CREATE TABLE Books (
ID INT PRIMARY KEY IDENTITY(1,1),
Publisher VARCHAR(150),
Title VARCHAR(100),
AuthorLastName VARCHAR(100),
AuthorFirstName VARCHAR(100),
TitleOfContainer VARCHAR(MAX),
Price DECIMAL(18,2),
PublicationDate DATE, 
PageCount INT 
);



CREATE PROCEDURE FetechSortedBy_PublisherAuthorTitle
AS
BEGIN 

SELECT * FROM Books ORDER BY Publisher, AuthorLastName, AuthorFirstName, Title;

END;


CREATE PROCEDURE FetchSortedBy_AuthorTitle
AS
BEGIN
    SELECT * FROM Books ORDER BY AuthorLastName, AuthorFirstName, Title;
END;


CREATE PROCEDURE FetchTotalPrice
AS
BEGIN
    SELECT SUM(Price) AS TotalPrice FROM Books;
END;	

SELECT SUM(UserTypeID) AS US FROM UserTypes