﻿using Microsoft.EntityFrameworkCore;
using SampleMVCApplication.Models;

namespace SampleMVCApplication.Data
{
    public class BookDBContext : DbContext
    {
        public BookDBContext(DbContextOptions<BookDBContext> option) : base(option) { }

        public DbSet<Book> Books { get; set; }
    }
}
