﻿using SampleMVCApplication.Models;

namespace SampleMVCApplication.Repository
{
    public interface IBookRepository
    {
        Task<IEnumerable<Book>> FetchBooksAuthorTitle();
        Task<IEnumerable<Book>> FetchBooksPublisherAuthorTitle();
        Task<IEnumerable<Book>> FetchBooksAuthorTitleSP();
        Task<IEnumerable<Book>> FetchBooksPublisherAuthorTitleSP();
        Task<decimal> FetchTotalPrice();
    }
}
