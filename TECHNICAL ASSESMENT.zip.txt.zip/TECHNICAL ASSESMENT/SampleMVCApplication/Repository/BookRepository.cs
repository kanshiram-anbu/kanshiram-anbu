﻿using Microsoft.EntityFrameworkCore;
using SampleMVCApplication.Models;
using SampleMVCApplication.Data;

namespace SampleMVCApplication.Repository
{
    public class BookRepository : IBookRepository
    {
        private readonly BookDBContext _bookdBContext;
        public BookRepository(BookDBContext bookDBContext)
        {
            _bookdBContext = bookDBContext;
        }

        public async Task<IEnumerable<Book>> FetchBooksAuthorTitleSP()
        {
            var books = await _bookdBContext.Books.FromSqlRaw("EXEC FetchSortedBy_AuthorTitle").ToListAsync();
            return books;
        }

        public async Task<IEnumerable<Book>> FetchBooksPublisherAuthorTitleSP()
        {
            var books = await _bookdBContext.Books.FromSqlRaw("EXEC FetechSortedBy_PublisherAuthorTitle").ToListAsync();

            return books;
        }

        public async Task<IEnumerable<Book>> FetchBooksAuthorTitle()
        {
            return await _bookdBContext.Books
                .OrderBy(b => b.AuthorLastName)
                .ThenBy(b => b.AuthorFirstName)
                .ThenBy(b => b.Title)
                .ToListAsync();
        }

        public async Task<IEnumerable<Book>> FetchBooksPublisherAuthorTitle()
        {
            return await _bookdBContext.Books
                                .OrderBy(b => b.Publisher)
                .ThenBy(b => b.AuthorLastName)
                .ThenBy(b => b.AuthorFirstName)
                .ThenBy(b => b.Title)
                .ToListAsync();
        }

        public async Task<decimal> FetchTotalPrice()
        {
            var res = await _bookdBContext.Set<Book>()
                .FromSqlRaw("EXEC FetchTotalPrice")
                .ToListAsync();
            return res.FirstOrDefault()?.Price ?? 0m;
        }
    }
}
