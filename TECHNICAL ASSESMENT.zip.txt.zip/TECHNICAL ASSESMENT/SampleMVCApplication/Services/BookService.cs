﻿using Microsoft.EntityFrameworkCore;
using SampleMVCApplication.Data;
using SampleMVCApplication.Models;
using SampleMVCApplication.Repository;

namespace SampleMVCApplication.Services
{
    public class BookService : IBookService 
    {
        private readonly BookRepository _bookRepository;
        public BookService(BookRepository bookRepository) {

            _bookRepository = bookRepository;
        }

        public async Task<IEnumerable<Book>> FetchBooksAuthorTitleSP()
        {
            return await _bookRepository.FetchBooksAuthorTitleSP();
        }

        public async Task<IEnumerable<Book>> FetchBooksPublisherAuthorTitleSP()
        {
            return await _bookRepository.FetchBooksPublisherAuthorTitleSP();
        }

        public async Task<IEnumerable<Book>> FetchBooksAuthorTitle()
        {
            return await _bookRepository.FetchBooksAuthorTitle();
        }

        public async Task<IEnumerable<Book>> FetchBooksPublisherAuthorTitle()
        {
            return await _bookRepository.FetchBooksPublisherAuthorTitle();
        }

        public async Task<decimal> FetchTotalPrice()
        {
            return await _bookRepository.FetchTotalPrice();
        }
    }
}
