﻿using SampleMVCApplication.Models;

namespace SampleMVCApplication.Services
{
    public interface IBookService
    {
        Task<IEnumerable<Book>> FetchBooksPublisherAuthorTitle();
        Task<IEnumerable<Book>> FetchBooksAuthorTitle();
        Task<IEnumerable<Book>> FetchBooksPublisherAuthorTitleSP();
        Task<IEnumerable<Book>> FetchBooksAuthorTitleSP();
        Task<Decimal> FetchTotalPrice();
    }
}
